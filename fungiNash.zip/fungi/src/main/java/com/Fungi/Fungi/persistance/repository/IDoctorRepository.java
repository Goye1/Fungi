package com.Fungi.Fungi.persistance.repository;
import com.Fungi.Fungi.persistance.entity.Doctor;
import com.Fungi.Fungi.persistance.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IDoctorRepository extends JpaRepository<Doctor,Long> {
    boolean existsBylicenseNumber(Integer licenseNumber);

    Doctor findBylicenseNumber(Integer licenseNumber);
    Doctor findByEmail(String email);
}
