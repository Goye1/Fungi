package com.Fungi.Fungi.service;

import com.Fungi.Fungi.exceptions.AlreadyExistsException;
import com.Fungi.Fungi.exceptions.ResourceNotFoundException;
import com.Fungi.Fungi.persistance.entity.Patient;
import com.Fungi.Fungi.persistance.repository.IPatientRepository;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientService {
    private final IPatientRepository patientRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    public PatientService(IPatientRepository patientRepository , DoctorService doctorService) {
        this.patientRepository = patientRepository;
    }

    public void addPatient(Patient patient) throws AlreadyExistsException {
            patientRepository.save(patient);

    }



    public Patient findById(Long id) throws ResourceNotFoundException {
        return patientRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Patient with the id: " + id + "not found"));
    }

    public Patient findByEmail(String email) throws ResourceNotFoundException {
        Patient patient = patientRepository.findByEmail(email);
        if(patient == null){
            throw new ResourceNotFoundException("User not found");
        }
        return patient;
    }






}

