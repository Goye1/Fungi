package com.Fungi.Fungi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FungiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FungiApplication.class, args);
	}

}
