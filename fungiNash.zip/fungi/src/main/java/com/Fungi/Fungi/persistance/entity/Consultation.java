package com.Fungi.Fungi.persistance.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
@Table
public class Consultation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "id_medico")
    private Doctor doctor;
    @ManyToOne
    @JoinColumn(name = "id_form")
    private Form form;
    @ManyToOne
    @JoinColumn(name = "id_patient")
    private Patient patient;
}
