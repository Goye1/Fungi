package com.Fungi.Fungi.service;
import com.Fungi.Fungi.exceptions.ResourceNotFoundException;
import com.Fungi.Fungi.persistance.entity.Doctor;
import com.Fungi.Fungi.persistance.entity.Patient;
import com.Fungi.Fungi.persistance.repository.IDoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.print.Doc;
import java.util.List;


@Service
public class DoctorService {

   private final IDoctorRepository doctorRepository;

    @Autowired
    public DoctorService(IDoctorRepository dentistRepository) {
        this.doctorRepository = dentistRepository;
    }

    public List<Doctor> listDentists() throws ResourceNotFoundException {
        return doctorRepository.findAll();
    }

    public Doctor addDoctor(Doctor doctor) throws ResourceNotFoundException {
        if (doctorRepository.existsBylicenseNumber(doctor.getLicenseNumber())) {
            throw new ResourceNotFoundException("A dentist with " + doctor.getLicenseNumber() + " license number already exists");
        }
        doctorRepository.save(doctor);
        return doctor;
    }
    public Doctor findByEmail(String email) throws ResourceNotFoundException {
        Doctor doctor = doctorRepository.findByEmail(email);
        if(doctor == null){
            throw new ResourceNotFoundException("User not found");
        }
        return doctor;
    }



}

