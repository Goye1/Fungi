package com.Fungi.Fungi.persistance.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
@Setter
@Getter
public class Form {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ElementCollection
    @CollectionTable(name = "form_questions", joinColumns = @JoinColumn(name = "form_id"))
    @Column(name = "question")
    private Set<String> questions = new HashSet<>();
    @ElementCollection
    @CollectionTable(name = "form_dr_answers", joinColumns = @JoinColumn(name = "form_id"))
    @Column(name = "dr_answer")
    private Set<String> drAnswers = new HashSet<>();
    @ManyToOne
    @JoinColumn(name = "id_medico")
    private Doctor doctor;


}