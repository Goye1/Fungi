package com.Fungi.Fungi.persistance.entity;

public enum Role {
    ADMIN,
    USER
}
