package com.Fungi.Fungi.exceptions;

public class AlreadyExistsException extends Exception{

    public AlreadyExistsException(String message) {
        super(message);
    }
}
